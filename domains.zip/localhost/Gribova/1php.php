<?php
$arr = [1=>"Брюки спортивные", "Футболка спортивная", "Кроссовки для бега"];
$otv1 = "Неизвестно";
if (isset($_POST['otv1']))
$otv1 = $_POST['otv1'];
if ($otv1=="да"||$otv1=="Да"||$otv1=="ДА"||$otv1=="дА"){
echo "<h2> <i><font color='green'>Самые спортивные вещи в нашем магазине:</i></font></h2>";
foreach($arr as $key => $value)
{echo "<font color='red'><b>{$key}</b></font> - {$value}<br/>";}
?>
<h3>Введите номер понравившейся вещи, и я расскажу вам подробнее о ней!</h3>
<form action="2php.php" method="POST">
Ответ: <input type="text" name="otv2"/><br><br>
<input type="submit" value="Ответить">
<br><br>
<a href="Gribova_SportWear.html"> Вернуться в начало </a>
<?php
}
else if ($otv1=="") echo "Вы ничего не выбрали...";
else echo "Нас огорчил Ваш ответ! Попробуйте еще раз!!";
?>
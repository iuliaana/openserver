<?php
$otv2 = "Неизвестно";
if (isset($_POST['otv2']))
$otv2 = $_POST['otv2'];
switch ($otv2)
{
	case 1 : echo "<h2> Топ 1 <b>Брюки спортивные</b> </h2> самое крутое описание <h3> Хотите приобрести топ 1 вещь в нашем магазине? </h3>
	<form action='3php.php' method='POST'>
	Ответ: <input type='text' name='otv3' /><br></br>
	<input type='submit' value='Ответить'>";
	break;
	case 2 : echo "Топ 2 <b>Футболка спортивная</b> </h2>  крутое описание <h3> Хотите приобрести топ 2 вещь в нашем магазине? </h3>
	<form action='3php.php' method='POST'>
	Ответ: <input type='text' name='otv3' /><br></br>
	<input type='submit' value='Ответить'>";
	break;
	case 3 : echo "Топ 3 <b>Кроссовки для бега</b> </h2> простое описание <h3> Хотите приобрести топ 3 вещь в нашем магазине? </h3>
	<form action='3php.php' method='POST'>
	Ответ: <input type='text' name='otv3' /><br></br>
	<input type='submit' value='Ответить'>";
	break;
	default : echo "Нас огорчил Ваш ответ! Попробуйте еще раз!!";
	break;
}
?>
<br><br>
<a href="Gribova_SportWear.html"> Вернуться в начало </a>
</form>
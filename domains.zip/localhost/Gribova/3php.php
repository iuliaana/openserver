<html>
<form action="4php.php" method="POST">
<p><b>Предпочитаемый цвет модели?</b></p>
<h2> <p><input name="dzen" type="radio" value="blue"> Синий</h2></p>
<h2> <p><input name="dzen" type="radio" value="yellow"> Желтый</h2></p>
<h2> <p><input name="dzen" type="radio" value="green" checked> Хаки</h2></p>
<p><b>Упаковать?</p></b>
<p><input type="checkbox" name="option1" value="Необходимо упаковать" checked>Да<br>
<p><input type="submit" value="Выбрать"></p>
</form>
</html>
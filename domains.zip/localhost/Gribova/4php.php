<?php
if (isset($_POST['dzen'])){
	$otv5=$_POST['dzen'];
	echo "<h1>$otv5</h1>";
	$otv6=$_POST['option1'];
	echo "<h2>$otv6</h2>";
}
?>
<html>
<form>
<form action="5php.php" method="POST">
<p><b>Посмостреть остальные товары??</b></p>
<a href="5php.php">Да!</a>
</form>
</html>

<!DOCTYPE html>
<html>
<h2 align="center"><i><font color="green"> Представленные категории</i></h2></font>
<select>
<option value="vidt.php">Вид товара</option> 
<option value="marka.php">Марка</option> 
<option value="sezona.php">Сезоны</option> 
<option value="1php.php">Топ товаров</option> 
</select>

<p><input type="submit" value="Выбрать"></p>
</form>
</body>
</html>
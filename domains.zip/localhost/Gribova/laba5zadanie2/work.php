<!DOCTYPE html>
<html>
 <head>
  <meta charset="utf-8">
  <title>Заявка</title>
  <style>
   body {
    background: #16171b;
    color: #ffffff;
   }
  </style>
 </head>
 </html>
 
 <h2 align="center"> <font size 14 face="Arial"> <i>Результаты записаны в текстовый файл</face></h2>
 
<?php
$name = $_POST['name'];
$surname = $_POST['surname'];
$otch = $_POST['otch'];
$phone = $_POST['phone'];
$birth = $_POST['birth'];
$bludo = $_POST['bludo'];
$a = $_POST['a'];
$file = fopen("$name $surname $a .txt","at");
fwrite($file,"Имя: $name
Фамилия: $surname
Отчество: $otch 
Номер телефона: $phone 
Дата рождения: $birth,
Серия и номер паспорта: $bludo 
СНИЛС: $a");
fclose($file);
?>

<?php
echo "<strong>Имя: </strong> $name <br/>";
echo "<strong>Фамилия: </strong> $surname <br/>";
echo "<strong>Отчество: </strong> $otch <br/>";
echo "<strong>Номер телефона: </strong> $phone <br/>";
echo "<strong>Дата рождения: </strong> $birth <br/>";
echo "<strong>Серия и номер паспорта: </strong> $bludo <br/>";
echo "<strong>СНИЛС: </strong> $a <br/>";
?>
<?php
$fd = fopen("lab5zaanie2.php","a+");
$name = $_POST['name'];
$surname = $_POST['surname'];
$group = $_POST['group'];
$mail = $_POST['mail'];
$predmet = $_POST['predmet'];
$vg = $_POST['vg'];
$sport = $_POST['sport'];
$msg = $_POST['msg'];
fwrite($fd, " $name, $surname, $group, $mail, $predmet, $vg, $sport, $msg");
fclose($fd);
?>
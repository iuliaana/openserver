<p> Грибова Юлия 31ИС-19 <p>
<?php 
$var1 = '3';
$var2 = 5;
echo $var1 . '-' . gettype($var1) . '<br>';
print ($var2 . ' - ' . gettype($var2) . '<br>');
$var3 = 'abc';
var_dump ($var3);
echo '<br>';
$var4=123;
var_dump($var4);
?>
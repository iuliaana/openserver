<p> Грибова Юлия 31ИС
Вариант 9
<p>
<?php
function doubleAlph($n){
    if($n < 0)return;
       $str = 'A';
    for($i = 0; $i < $n; $i++){
        $char = substr($str, 0, 1);
        $ascii = ord($char);
        $str = chr($ascii+1).' '.$str.' '.chr($ascii+1);
        }
    return $str.'<br>';
    }
$n = 6;
for ($i = 0; $i <= $n; $i++){
    if(($n - $i) > $i){
        echo doubleAlph($i);
        }
    else{
        echo doubleAlph($n-$i);
        }
    }
?>

Создайте файл twelve.html с содержимым:
Напишите функцию twelverecord, которая записывает в начало файла twelve.html теги “<html><body>” и в конец файла теги “</body></html>” 
Напишите функцию  onefunc, которая удаляет файл 1.txt если он есть,  создает файл 2.txt если нет файла 1.txt  и записывает в него ФИО студента, группу, любое животное. 
<?php $filed = "labphp5.html";
$rez = file_get_contents($filed);
$rez .= "</body></html>";
file_put_contents($filed, $rez);
?>
<?php
$file_data = "<html><body>";
$file_data .= file_get_contents('labphp5.html');
file_put_contents('labphp5.html', $file_data);
?>
<?php
if (unlink("1.txt"))
    echo "Файл удален";
else echo "Ошибка при удалении файла";
?>
<?php
if (unlink("1.txt"))
$h = fopen("2.txt","x+");
$fd=fopen("2.txt","r"); fwrite($fd, "Грибова Юлия Геннадьевна, 31ИС-19, кот!"); fclose($fd); 
?>
